import 'package:wanderly/core/app_export.dart';

class ApiClient {}
